import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, CheckCircle, Star } from 'lucide-react';
import { Link } from 'react-router-dom';

interface Service {
  id: string;
  title: string;
  description: string | null;
  icon: string | null;
  features: string[];
  is_active: boolean;
  sort_order: number;
}

const ImprovedServices = () => {
  const [activeService, setActiveService] = useState<number>(0);
  
  const { data: services = [], isLoading } = useQuery({
    queryKey: ['/api/services'],
  });

  const activeServices = services.filter((service: Service) => service.is_active)
    .sort((a: Service, b: Service) => a.sort_order - b.sort_order);

  if (isLoading) {
    return (
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-white relative overflow-hidden">
      {/* Simple background */}
      <div className="absolute inset-0 bg-gradient-to-br from-gray-50/30 to-purple-50/30"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-100 text-purple-700 rounded-full text-sm font-medium mb-4">
            <Star className="w-4 h-4" />
            خدماتنا المميزة
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            تجارب سياحية استثنائية
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            نقدم مجموعة متنوعة من الخدمات السياحية المتميزة التي تناسب جميع الأذواق والاحتياجات
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {activeServices.map((service: Service, index: number) => (
            <div 
              key={service.id}
              className={`group relative bg-white rounded-2xl p-8 shadow-lg border-2 transition-all duration-300 hover:shadow-xl cursor-pointer ${
                activeService === index ? 'border-purple-200 bg-purple-50/50' : 'border-gray-100 hover:border-purple-200'
              }`}
              onMouseEnter={() => setActiveService(index)}
            >
              {/* Service icon */}
              <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <span className="text-2xl text-white">
                  {service.icon || '⭐'}
                </span>
              </div>
              
              {/* Service content */}
              <h3 className="text-2xl font-bold text-gray-800 mb-4 group-hover:text-purple-600 transition-colors">
                {service.title}
              </h3>
              
              <p className="text-gray-600 mb-6 leading-relaxed">
                {service.description}
              </p>
              
              {/* Features */}
              <div className="space-y-3 mb-8">
                {service.features.slice(0, 3).map((feature, idx) => (
                  <div key={idx} className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                    <span className="text-gray-700">{feature}</span>
                  </div>
                ))}
                {service.features.length > 3 && (
                  <div className="text-sm text-gray-500 mt-2">
                    +{service.features.length - 3} ميزة إضافية
                  </div>
                )}
              </div>
              
              {/* Action button */}
              <Link
                to="/booking"
                className="group/btn w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 px-6 rounded-xl font-medium hover:from-purple-700 hover:to-pink-700 transition-all duration-300 flex items-center justify-center gap-2"
              >
                احجز الآن
                <ArrowLeft className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
              </Link>
              
              {/* Hover effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600/5 to-pink-600/5 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center">
          <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-8 max-w-4xl mx-auto border border-purple-100">
            <h3 className="text-2xl font-bold text-gray-800 mb-4">
              لم تجد ما تبحث عنه؟
            </h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              يمكننا تخصيص تجربة سياحية خاصة تناسب احتياجاتك ومتطلباتك الفريدة
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/booking"
                className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-3 rounded-xl font-medium hover:from-purple-700 hover:to-pink-700 transition-all duration-300 flex items-center justify-center gap-2"
              >
                طلب تجربة مخصصة
                <ArrowLeft className="w-4 h-4" />
              </Link>
              
              <Link
                to="/contact"
                className="border-2 border-gray-300 text-gray-700 px-8 py-3 rounded-xl font-medium hover:border-purple-300 hover:text-purple-600 transition-all duration-300"
              >
                تواصل معنا
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ImprovedServices;