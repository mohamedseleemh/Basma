
import React from 'react';
import Navigation from '../components/Navigation';
import ImprovedHeader from '../components/ImprovedHeader';
import ImprovedServices from '../components/ImprovedServices';
import ImprovedTestimonials from '../components/ImprovedTestimonials';
import ImprovedGallery from '../components/ImprovedGallery';
import ImprovedContact from '../components/ImprovedContact';
import Footer from '../components/Footer';

const Index = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      <ImprovedHeader />
      <ImprovedServices />
      <ImprovedTestimonials />
      <ImprovedGallery />
      <ImprovedContact />
      <Footer />
    </div>
  );
};

export default Index;
